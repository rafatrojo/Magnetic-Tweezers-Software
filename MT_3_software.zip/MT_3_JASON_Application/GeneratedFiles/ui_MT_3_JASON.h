/********************************************************************************
** Form generated from reading UI file 'MT_3_JASON.ui'
**
** Created by: Qt User Interface Compiler version 5.11.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MT_3_JASON_H
#define UI_MT_3_JASON_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MT_3_JASONClass
{
public:
    QWidget *centralWidget;
    QDoubleSpinBox *FocusBox;
    QPushButton *ROIButton;
    QPushButton *SaveDataButton;
    QCheckBox *View_fast_slow;
    QPushButton *stackButton;
    QPushButton *MeasureButton;
    QLabel *I_textBox;
    QLabel *FramesPerSecondText;
    QPlainTextEdit *Pulse_protocol;
    QDoubleSpinBox *CurrentBox;
    QCheckBox *lockReference;
    QLabel *version;
    QLabel *label_3;
    QPushButton *execute_pulse;
    QPushButton *LoadPulseProtocolFromFile;
    QPushButton *close_JSON_file;
    QCheckBox *BeadType;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MT_3_JASONClass)
    {
        if (MT_3_JASONClass->objectName().isEmpty())
            MT_3_JASONClass->setObjectName(QStringLiteral("MT_3_JASONClass"));
        MT_3_JASONClass->resize(242, 233);
        centralWidget = new QWidget(MT_3_JASONClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        FocusBox = new QDoubleSpinBox(centralWidget);
        FocusBox->setObjectName(QStringLiteral("FocusBox"));
        FocusBox->setGeometry(QRect(160, 10, 51, 22));
        FocusBox->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        FocusBox->setButtonSymbols(QAbstractSpinBox::NoButtons);
        FocusBox->setDecimals(0);
        FocusBox->setSingleStep(100);
        ROIButton = new QPushButton(centralWidget);
        ROIButton->setObjectName(QStringLiteral("ROIButton"));
        ROIButton->setGeometry(QRect(12, 70, 71, 28));
        QPalette palette;
        QBrush brush(QColor(0, 0, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        QBrush brush1(QColor(120, 120, 120, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        ROIButton->setPalette(palette);
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        ROIButton->setFont(font);
        SaveDataButton = new QPushButton(centralWidget);
        SaveDataButton->setObjectName(QStringLiteral("SaveDataButton"));
        SaveDataButton->setGeometry(QRect(12, 130, 71, 28));
        QPalette palette1;
        QBrush brush2(QColor(170, 0, 127, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Active, QPalette::ButtonText, brush2);
        palette1.setBrush(QPalette::Inactive, QPalette::ButtonText, brush2);
        palette1.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        SaveDataButton->setPalette(palette1);
        SaveDataButton->setFont(font);
        View_fast_slow = new QCheckBox(centralWidget);
        View_fast_slow->setObjectName(QStringLiteral("View_fast_slow"));
        View_fast_slow->setGeometry(QRect(160, 40, 20, 31));
        View_fast_slow->setLayoutDirection(Qt::RightToLeft);
        stackButton = new QPushButton(centralWidget);
        stackButton->setObjectName(QStringLiteral("stackButton"));
        stackButton->setGeometry(QRect(12, 40, 71, 28));
        QPalette palette2;
        QBrush brush3(QColor(170, 0, 0, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette2.setBrush(QPalette::Active, QPalette::ButtonText, brush3);
        palette2.setBrush(QPalette::Inactive, QPalette::ButtonText, brush3);
        palette2.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        stackButton->setPalette(palette2);
        stackButton->setFont(font);
        stackButton->setLayoutDirection(Qt::LeftToRight);
        MeasureButton = new QPushButton(centralWidget);
        MeasureButton->setObjectName(QStringLiteral("MeasureButton"));
        MeasureButton->setGeometry(QRect(12, 100, 71, 28));
        QPalette palette3;
        QBrush brush4(QColor(0, 170, 0, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette3.setBrush(QPalette::Active, QPalette::ButtonText, brush4);
        palette3.setBrush(QPalette::Inactive, QPalette::ButtonText, brush4);
        palette3.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        MeasureButton->setPalette(palette3);
        MeasureButton->setFont(font);
        MeasureButton->setAutoFillBackground(false);
        MeasureButton->setCheckable(false);
        MeasureButton->setFlat(false);
        I_textBox = new QLabel(centralWidget);
        I_textBox->setObjectName(QStringLiteral("I_textBox"));
        I_textBox->setGeometry(QRect(10, 10, 41, 21));
        I_textBox->setFrameShape(QFrame::NoFrame);
        I_textBox->setFrameShadow(QFrame::Plain);
        I_textBox->setTextFormat(Qt::RichText);
        I_textBox->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        FramesPerSecondText = new QLabel(centralWidget);
        FramesPerSecondText->setObjectName(QStringLiteral("FramesPerSecondText"));
        FramesPerSecondText->setGeometry(QRect(90, 40, 71, 31));
        QPalette palette4;
        palette4.setBrush(QPalette::Active, QPalette::Text, brush3);
        palette4.setBrush(QPalette::Inactive, QPalette::Text, brush3);
        palette4.setBrush(QPalette::Disabled, QPalette::Text, brush1);
        FramesPerSecondText->setPalette(palette4);
        QFont font1;
        font1.setFamily(QStringLiteral("Arial"));
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        FramesPerSecondText->setFont(font1);
        FramesPerSecondText->setFrameShape(QFrame::Box);
        FramesPerSecondText->setFrameShadow(QFrame::Sunken);
        FramesPerSecondText->setLineWidth(2);
        FramesPerSecondText->setTextFormat(Qt::RichText);
        FramesPerSecondText->setScaledContents(false);
        FramesPerSecondText->setAlignment(Qt::AlignCenter);
        Pulse_protocol = new QPlainTextEdit(centralWidget);
        Pulse_protocol->setObjectName(QStringLiteral("Pulse_protocol"));
        Pulse_protocol->setGeometry(QRect(90, 70, 111, 81));
        QFont font2;
        font2.setFamily(QStringLiteral("Arial"));
        font2.setPointSize(9);
        Pulse_protocol->setFont(font2);
        Pulse_protocol->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        CurrentBox = new QDoubleSpinBox(centralWidget);
        CurrentBox->setObjectName(QStringLiteral("CurrentBox"));
        CurrentBox->setGeometry(QRect(50, 10, 41, 22));
        CurrentBox->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        CurrentBox->setButtonSymbols(QAbstractSpinBox::NoButtons);
        CurrentBox->setDecimals(0);
        lockReference = new QCheckBox(centralWidget);
        lockReference->setObjectName(QStringLiteral("lockReference"));
        lockReference->setGeometry(QRect(210, 10, 20, 20));
        lockReference->setLayoutDirection(Qt::RightToLeft);
        version = new QLabel(centralWidget);
        version->setObjectName(QStringLiteral("version"));
        version->setGeometry(QRect(20, 160, 211, 20));
        version->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(100, 10, 51, 21));
        label_3->setFrameShape(QFrame::NoFrame);
        label_3->setFrameShadow(QFrame::Plain);
        label_3->setTextFormat(Qt::RichText);
        label_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        execute_pulse = new QPushButton(centralWidget);
        execute_pulse->setObjectName(QStringLiteral("execute_pulse"));
        execute_pulse->setGeometry(QRect(210, 100, 21, 21));
        QPalette palette5;
        QBrush brush5(QColor(85, 0, 255, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette5.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette5.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette5.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        execute_pulse->setPalette(palette5);
        execute_pulse->setFont(font);
        LoadPulseProtocolFromFile = new QPushButton(centralWidget);
        LoadPulseProtocolFromFile->setObjectName(QStringLiteral("LoadPulseProtocolFromFile"));
        LoadPulseProtocolFromFile->setGeometry(QRect(210, 70, 21, 21));
        QPalette palette6;
        palette6.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette6.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette6.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        LoadPulseProtocolFromFile->setPalette(palette6);
        LoadPulseProtocolFromFile->setFont(font);
        LoadPulseProtocolFromFile->setFlat(false);
        close_JSON_file = new QPushButton(centralWidget);
        close_JSON_file->setObjectName(QStringLiteral("close_JSON_file"));
        close_JSON_file->setGeometry(QRect(210, 130, 21, 21));
        QPalette palette7;
        palette7.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette7.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette7.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        close_JSON_file->setPalette(palette7);
        close_JSON_file->setFont(font);
        BeadType = new QCheckBox(centralWidget);
        BeadType->setObjectName(QStringLiteral("BeadType"));
        BeadType->setGeometry(QRect(90, 40, 121, 20));
        BeadType->setCheckable(true);
        MT_3_JASONClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MT_3_JASONClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 242, 26));
        MT_3_JASONClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MT_3_JASONClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MT_3_JASONClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MT_3_JASONClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MT_3_JASONClass->setStatusBar(statusBar);

        retranslateUi(MT_3_JASONClass);

        QMetaObject::connectSlotsByName(MT_3_JASONClass);
    } // setupUi

    void retranslateUi(QMainWindow *MT_3_JASONClass)
    {
        MT_3_JASONClass->setWindowTitle(QApplication::translate("MT_3_JASONClass", "MT_3_JASON", nullptr));
        ROIButton->setText(QApplication::translate("MT_3_JASONClass", "ROI", nullptr));
        SaveDataButton->setText(QApplication::translate("MT_3_JASONClass", "Save", nullptr));
        View_fast_slow->setText(QString());
        stackButton->setText(QApplication::translate("MT_3_JASONClass", "Stack", nullptr));
        MeasureButton->setText(QApplication::translate("MT_3_JASONClass", "Measure", nullptr));
        I_textBox->setText(QApplication::translate("MT_3_JASONClass", "F (pN)", nullptr));
        FramesPerSecondText->setText(QString());
        lockReference->setText(QString());
        version->setText(QString());
        label_3->setText(QApplication::translate("MT_3_JASONClass", "OP (nm)", nullptr));
        execute_pulse->setText(QApplication::translate("MT_3_JASONClass", "P", nullptr));
        LoadPulseProtocolFromFile->setText(QApplication::translate("MT_3_JASONClass", "L", nullptr));
        close_JSON_file->setText(QApplication::translate("MT_3_JASONClass", "C", nullptr));
        BeadType->setText(QApplication::translate("MT_3_JASONClass", "M270/M450", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MT_3_JASONClass: public Ui_MT_3_JASONClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MT_3_JASON_H
