/********************************************************************************
** Form generated from reading UI file 'MT_3.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MT_3_H
#define UI_MT_3_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MT_3Class
{
public:
    QWidget *centralWidget;
    QPushButton *pushButton;
    QTextEdit *textEdit;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MT_3Class)
    {
        if (MT_3Class->objectName().isEmpty())
            MT_3Class->setObjectName(QStringLiteral("MT_3Class"));
        MT_3Class->resize(945, 630);
        centralWidget = new QWidget(MT_3Class);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(20, 10, 421, 181));
        textEdit = new QTextEdit(centralWidget);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(450, 200, 421, 371));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(20, 200, 421, 181));
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(20, 390, 421, 181));
        pushButton_4 = new QPushButton(centralWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(450, 10, 421, 181));
        MT_3Class->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MT_3Class);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 945, 20));
        MT_3Class->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MT_3Class);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MT_3Class->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MT_3Class);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MT_3Class->setStatusBar(statusBar);

        retranslateUi(MT_3Class);

        QMetaObject::connectSlotsByName(MT_3Class);
    } // setupUi

    void retranslateUi(QMainWindow *MT_3Class)
    {
        MT_3Class->setWindowTitle(QApplication::translate("MT_3Class", "MT_3", nullptr));
        pushButton->setText(QApplication::translate("MT_3Class", "Open JSON file", nullptr));
        pushButton_2->setText(QApplication::translate("MT_3Class", "Write to file", nullptr));
        pushButton_3->setText(QApplication::translate("MT_3Class", "Close file", nullptr));
        pushButton_4->setText(QApplication::translate("MT_3Class", "Read JSON", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MT_3Class: public Ui_MT_3Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MT_3_H
