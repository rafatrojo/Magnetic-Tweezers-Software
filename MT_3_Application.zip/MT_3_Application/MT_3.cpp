#include "MT_3.h"
#include <QStandardPaths>
#include <iostream>
#include <fstream>
#include "stdio.h"
#include <Windows.h>
#include <nlohmann/json.hpp>
#include <iomanip>
#include <ctime>

using namespace std;
using json = nlohmann::json;
ofstream MT_JASON;
json Experiment;

MT_3::MT_3(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	connect(ui.pushButton, &QPushButton::released, this, &MT_3::Open_Json);
	connect(ui.pushButton_2, &QPushButton::released, this, &MT_3::Write_Json);
	connect(ui.pushButton_3, &QPushButton::released, this, &MT_3::Close_Json);
	connect(ui.pushButton_4, &QPushButton::released, this, &MT_3::Read_Json);
	QWidget::move(400, 10);
}

void MT_3::Write_Json()
{
	time_t t0 = std::time(0);
	Experiment["Meta_Data"] = { {"operator", "Rafael"}, {"Protein", "L"}, {"date (s)", t0} };
	for (int i = 0; i < 5000000; i++) { Experiment[to_string(i)] = { i/2,(double)rand() / RAND_MAX,i*2 }; }
	MT_JASON << std::setw(4) << Experiment;// << std::endl;
}

void MT_3::Open_Json()
{
	MT_JASON.open("../../pretty.json",std::ios_base::app);
	MT_JASON.clear();
}

void MT_3::Close_Json()
{
	MT_JASON.close();
	MT_JASON << std::endl;
}

void MT_3::Read_Json()
{
	ifstream MT_JASON_R("../../pretty.json");
	json E_read;
	MT_JASON_R >> E_read;
	double n0 = E_read["1"][1].get_to(n0);
	ui.textEdit->append(QString::number(n0));
	int n1;
	E_read["Meta_Data"]["date (s)"].get_to(n1);
	ui.textEdit->append(QString::number(n1));
	string n2;
	E_read["Meta_Data"]["operator"].get_to(n2);
	QString q = n2.c_str();
	ui.textEdit->append(q);
	MT_JASON_R.close();
}