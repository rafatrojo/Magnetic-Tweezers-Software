#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_MT_3.h"
#include <QStandardPaths>
#include <iostream>
#include <fstream>
#include "stdio.h"
#include <Windows.h>
#include <nlohmann/json.hpp>
#include <iomanip>
#include <ctime>

class MT_3 : public QMainWindow
{
	Q_OBJECT

public:
	MT_3(QWidget *parent = Q_NULLPTR);
	void Open_Json();
	void Write_Json();
	void Close_Json();
	void Read_Json();


private:
	Ui::MT_3Class ui;
};
