#include "MT_3_JASON.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	MT_3_JASON w;
	w.show();
	return a.exec();
}
