#pragma once

#include <QtWidgets/QMainWindow>
#include <xiApiPlusOcv.hpp>
#include <NIDAQmx.h>
#include "ui_MT_3_JASON.h"

class MT_3_JASON : public QMainWindow
{
	Q_OBJECT
public:
	MT_3_JASON(QWidget *parent = Q_NULLPTR);
	xiAPIplusCameraOcv cam;
	TaskHandle	taskHandle_0 = 0;
	TaskHandle	taskHandle_1 = 0;
	TaskHandle  taskHandle_2 = 0;
	TaskHandle  taskHandle_3 = 0;
	QGraphicsScene *scene;
	void ShowButtons(bool preview, bool init, bool ROI, bool stack);
	double CurrentForce_Law(double value, bool bead, QString direction);
	void UpdateBeadType();
public slots:
	void LoadPulseProtocol();
	void measure();
	void show_ROI();
	void get_stack();
	void Focus_box(int value);
	void Current_box(double MP);
	void Send_JSON_pulse(int cluster);
	void Clear_JSON_pulse();
	void Close_JSON_File();
private:
	Ui::MT_3_JASONClass ui;
};
